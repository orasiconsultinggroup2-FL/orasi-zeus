
const fs = require('fs');
const path = require('path');

const projectStructure = {
  'index.html': `<!DOCTYPE html>
<html lang="es" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZEUS Centro de Comando Élite</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#135bec",
                        "background-light": "#f6f6f8",
                        "background-dark": "#0a0f18",
                        "surface-dark": "#161b26",
                    },
                    fontFamily: {
                        "display": ["Manrope", "sans-serif"],
                        "sans": ["Manrope", "sans-serif"]
                    },
                },
            },
        }
    </script>
    <style>
        body { font-family: 'Manrope', sans-serif; -webkit-tap-highlight-color: transparent; overflow-x: hidden; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24 }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    </style>
</head>
<body class="bg-background-dark text-white antialiased">
    <div id="root"></div>
    <script type="module" src="/index.tsx"></script>
</body>
</html>`,
  'package.json': `{
  "name": "zeus-cce-orasi-lab",
  "version": "4.0.0",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^19.0.0",
    "react-dom": "^19.0.0",
    "react-router-dom": "^7.0.0",
    "@google/genai": "^1.30.0",
    "lucide-react": "^0.450.0",
    "recharts": "^2.12.0"
  },
  "devDependencies": {
    "vite": "^6.0.0",
    "typescript": "^5.0.0",
    "@types/react": "^19.0.0",
    "@types/react-dom": "^19.0.0"
  }
}`,
  '.env': `API_KEY=TU_LLAVE_AQUI_DE_GOOGLE_AI_STUDIO`,
  'README.md': `# CCE: Centro de Comando Élite\nPowered by ORASI Lab. Pilot Ready.`,
  '.gitignore': `node_modules/\n.env\ndist/\n.DS_Store`
};

// Crear archivos
Object.entries(projectStructure).forEach(([filename, content]) => {
    const dir = path.dirname(filename);
    if (dir !== '.') {
        fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(filename, content);
    console.log(`✅ Creado: ${filename}`);
});

console.log('\n🚀 ¡Estructura base lista! Ahora ejecuta: npm install');
