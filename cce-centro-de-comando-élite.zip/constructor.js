
const fs = require('fs');
const path = require('path');

const files = {
  'index.html': `<!DOCTYPE html>
<html lang="es" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ZEUS Centro de Comando Élite</title>
    <script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
    <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@300;400;500;600;700;800&display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            darkMode: "class",
            theme: {
                extend: {
                    colors: {
                        "primary": "#135bec",
                        "background-dark": "#0a0f18",
                        "surface-dark": "#161b26",
                    },
                    fontFamily: {
                        "display": ["Manrope", "sans-serif"],
                        "sans": ["Manrope", "sans-serif"]
                    },
                },
            },
        }
    </script>
    <style>
        body { font-family: 'Manrope', sans-serif; overflow-x: hidden; background: #0a0f18; }
        .material-symbols-outlined { font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24 }
        .fill-1 { font-variation-settings: 'FILL' 1 }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        @keyframes pulse-soft { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.8; transform: scale(0.98); } }
        .animate-pulse-soft { animation: pulse-soft 3s infinite ease-in-out; }
    </style>
</head>
<body class="text-white antialiased">
    <div id="root"></div>
    <script type="module" src="/index.tsx"></script>
</body>
</html>`,

  'index.tsx': `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(<React.StrictMode><App /></React.StrictMode>);`,

  'types.ts': `export enum AppRoute { HOME = '/', PIPELINE = '/pipeline', RADAR = '/radar', KPIS = '/kpis', GOVERNANCE = '/governance', RESOURCES = '/resources', OFFERS = '/offers', ACADEMY = '/academy' }
export enum UserRole { FFVV = 'FFVV', SUPERVISOR = 'SUPERVISOR', DIRECTIVO = 'DIRECTIVO' }
export type LeadStatus = 'PENDIENTE' | 'VALIDADO' | 'FALLIDO' | 'RESERVA';
export interface PipelineCard { id: string; title: string; probability: string; value: string; owner: string; nextStep: string; date: string; type: 'B2B' | 'EXPANSION'; status?: LeadStatus; validationReason?: string; }
export interface Offer { id: string; client: string; amount: string; status: string; date: string; type: string; }
export interface KanbanColumn { id: string; name: string; color: string; totalValue: string; cards: PipelineCard[]; }`,

  'services/geminiService.ts': `import { GoogleGenAI, Type } from "@google/genai";
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAIInsights = async (ctx: string) => {
  try {
    const res = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Analiza este contexto operativo y da 3 puntos clave: " + ctx,
    });
    return res.text;
  } catch (e) { return "Protocolo Offline activo."; }
};

export const parseVoiceCommand = async (cmd: string) => {
  try {
    const res = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: "Extrae ubicacion de: " + cmd,
      config: { 
        responseMimeType: "application/json",
        responseSchema: { type: Type.OBJECT, properties: { location: { type: Type.STRING } } }
      }
    });
    return JSON.parse(res.text || '{"location": "perímetro"}');
  } catch (e) { return { location: cmd }; }
};`,

  'components/Layout.tsx': `import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { AppRoute, UserRole } from '../types';

export const Layout = ({ children, role, onRoleChange }: any) => {
  const loc = useLocation();
  const menu = [
    { to: AppRoute.HOME, icon: 'dashboard', label: 'Dashboard' },
    { to: AppRoute.RADAR, icon: 'radar', label: 'Radar' },
    { to: AppRoute.GOVERNANCE, icon: 'verified_user', label: 'Gobernanza' },
    { to: AppRoute.PIPELINE, icon: 'view_kanban', label: 'Pipeline' },
    { to: AppRoute.OFFERS, icon: 'payments', label: 'Ofertas' },
    { to: AppRoute.ACADEMY, icon: 'school', label: 'Academia' }
  ];

  return (
    <div className="flex h-screen bg-[#0a0f18] text-white overflow-hidden">
      <aside className="w-72 border-r border-white/5 p-6 flex flex-col bg-[#0a0f18]">
        <div className="mb-10 text-center">
          <h1 className="text-3xl font-black tracking-tighter italic">ORASI <span className="text-primary">Lab</span></h1>
          <p className="text-[10px] uppercase tracking-[0.2em] opacity-50">Centro de Comando Elite</p>
        </div>
        <div className="mb-8 p-1 bg-white/5 rounded-xl flex border border-white/5">
          {Object.values(UserRole).map(r => (
            <button key={r} onClick={() => onRoleChange(r)} className={\`flex-1 py-1.5 text-[9px] font-black rounded-lg transition-all \${role === r ? 'bg-primary text-white shadow-lg' : 'text-slate-500'}\`}>{r}</button>
          ))}
        </div>
        <nav className="flex-1 space-y-2">
          {menu.map(m => (
            <Link key={m.to} to={m.to} className={\`flex items-center gap-3 p-4 rounded-2xl transition-all \${loc.pathname === m.to ? 'bg-primary shadow-xl shadow-primary/20' : 'hover:bg-white/5 text-slate-400'}\`}>
              <span className="material-symbols-outlined text-xl">{m.icon}</span>
              <span className="text-sm font-bold uppercase tracking-tight">{m.label}</span>
            </Link>
          ))}
        </nav>
      </aside>
      <main className="flex-1 overflow-y-auto p-10 bg-[#0a0f18]">{children}</main>
    </div>
  );
};`,

  'App.tsx': `import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { AppRoute, UserRole, KanbanColumn, PipelineCard, Offer } from './types';
import Home from './pages/Home';
import Pipeline from './pages/Pipeline';
import Radar from './pages/Radar';
import KPIs from './pages/KPIs';
import Governance from './pages/Governance';
import Resources from './pages/Resources';
import Offers from './pages/Offers';
import Academy from './pages/Academy';

const INITIAL_PIPELINE: KanbanColumn[] = [
  { id: 'c1', name: 'Prospección', color: 'bg-blue-400', totalValue: '$124k', cards: [] },
  { id: 'c2', name: 'Validación', color: 'bg-indigo-400', totalValue: '$850k', cards: [] },
  { id: 'c3', name: 'Cierre', color: 'bg-amber-400', totalValue: '$210k', cards: [] },
  { id: 'c4', name: 'Obra', color: 'bg-emerald-400', totalValue: '$45k', cards: [] }
];

const App = () => {
  const [role, setRole] = useState<UserRole>(UserRole.FFVV);
  const [pipelineData, setPipelineData] = useState<KanbanColumn[]>(INITIAL_PIPELINE);
  const [leads, setLeads] = useState<PipelineCard[]>([]);
  const [offers, setOffers] = useState<Offer[]>([]);

  const addLead = (l: PipelineCard) => setLeads(prev => [l, ...prev]);
  const addOffer = (o: Offer) => setOffers(prev => [o, ...prev]);
  const updateStatus = (id: string, s: any, r: string) => {
    setLeads(prev => prev.map(l => l.id === id ? { ...l, status: s, validationReason: r } : l));
    if(s === 'VALIDADO') {
       const lead = leads.find(l => l.id === id);
       if(lead) setPipelineData(curr => curr.map(col => col.id === 'c1' ? { ...col, cards: [lead, ...col.cards]} : col));
    }
  };

  return (
    <Router>
      <Layout role={role} onRoleChange={setRole}>
        <Routes>
          <Route path="/" element={<Home role={role} />} />
          <Route path="/radar" element={<Radar onAddLead={addLead} role={role} />} />
          <Route path="/pipeline" element={<Pipeline data={pipelineData} reserveLeads={leads.filter(l => l.status === 'RESERVA')} role={role} />} />
          <Route path="/governance" element={<Governance pendingLeads={leads.filter(l => l.status === 'PENDIENTE')} onValidate={updateStatus} />} />
          <Route path="/offers" element={<Offers offers={offers} onAddOffer={addOffer} role={role} />} />
          <Route path="/academy" element={<Academy />} />
          <Route path="/kpis" element={<KPIs role={role} />} />
          <Route path="/resources" element={<Resources />} />
        </Routes>
      </Layout>
    </Router>
  );
};
export default App;`,

  'pages/Home.tsx': `import React from 'react';
export default function Home({ role }: any) {
  return (
    <div className="space-y-12 animate-in fade-in duration-700">
      <header className="flex items-center gap-6">
        <div className="size-16 bg-primary rounded-[2rem] flex items-center justify-center shadow-2xl shadow-primary/40 animate-pulse-soft">
          <span className="material-symbols-outlined text-3xl">orbit</span>
        </div>
        <div>
          <h2 className="text-5xl font-black tracking-tighter italic uppercase">Estado del Comando</h2>
          <p className="text-emerald-400 text-[11px] font-black tracking-[0.4em] uppercase">Piloto Activo • Perfil: {role}</p>
        </div>
      </header>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="bg-[#161b26] p-10 rounded-[3rem] border border-white/5 shadow-2xl">
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">Pipeline Value</p>
          <h3 className="text-5xl font-black tracking-tighter">$8.4M</h3>
        </div>
        <div className="bg-[#161b26] p-10 rounded-[3rem] border border-white/5 shadow-2xl">
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-2">Leads Capturados</p>
          <h3 className="text-5xl font-black tracking-tighter">256</h3>
        </div>
        <div className="bg-primary p-10 rounded-[3rem] shadow-2xl shadow-primary/20">
          <p className="text-white/60 text-[10px] font-black uppercase tracking-widest mb-2">CAPEX Proyectado</p>
          <h3 className="text-5xl font-black tracking-tighter">$4.2M</h3>
        </div>
      </div>
    </div>
  );
}`,

  'pages/Radar.tsx': `import React, { useState } from 'react';
export default function Radar({ onAddLead }: any) {
  const [targets, setTargets] = useState<any[]>([]);
  const scan = () => {
    setTargets([
      { id: 'T1', name: 'Lote Norte Estratégico', type: 'EXPANSION', value: '$1.5M', dist: '0.8km' },
      { id: 'T2', name: 'Flota Transportes Andes', type: 'B2B', value: '$45k', dist: '1.2km' }
    ]);
  };
  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-5xl font-black tracking-tighter italic uppercase">Radar Territorial</h2>
          <p className="text-primary text-[10px] font-black uppercase tracking-[0.4em]">Escaneo en Tiempo Real</p>
        </div>
        <button onClick={scan} className="bg-primary px-12 py-5 rounded-[2rem] font-black text-xs uppercase shadow-2xl shadow-primary/30 hover:scale-105 transition-all">Lanzar Escaneo</button>
      </div>
      <div className="grid gap-6">
        {targets.map(t => (
          <div key={t.id} className="bg-[#161b26] p-10 rounded-[3rem] border border-white/5 flex items-center justify-between group hover:border-primary/40 transition-all shadow-xl">
            <div>
              <h3 className="text-3xl font-black italic uppercase tracking-tighter">{t.name}</h3>
              <p className="text-primary font-black text-xs uppercase mt-1">{t.type} • {t.value} • {t.dist}</p>
            </div>
            <button onClick={() => onAddLead({...t, title: t.name, status: 'PENDIENTE', probability: '85%'})} className="bg-primary/10 text-primary px-8 py-3 rounded-2xl text-[10px] font-black group-hover:bg-primary group-hover:text-white transition-all uppercase">Capturar</button>
          </div>
        ))}
      </div>
    </div>
  );
}`,

  'pages/Pipeline.tsx': `import React from 'react';
export default function Pipeline({ data }: any) {
  return (
    <div className="flex gap-8 overflow-x-auto pb-10 hide-scrollbar animate-in slide-in-from-right-10 duration-700">
      {data.map((col: any) => (
        <div key={col.id} className="min-w-[350px] space-y-6">
          <div className="flex justify-between items-center px-4">
            <h4 className="text-[11px] font-black uppercase text-slate-500 tracking-[0.3em] italic">{col.name}</h4>
            <span className="bg-white/5 px-3 py-1 rounded-full text-[10px] font-black border border-white/5">{col.cards.length}</span>
          </div>
          <div className="space-y-6">
            {col.cards.map((c: any) => (
              <div key={c.id} className="bg-[#161b26] p-8 rounded-[2.5rem] border border-white/5 shadow-2xl hover:border-primary/30 transition-all">
                <h5 className="font-black text-xl italic uppercase tracking-tight">{c.title}</h5>
                <p className="text-primary text-[10px] font-black uppercase mt-2">{c.value} • {c.probability}</p>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}`,

  'pages/Governance.tsx': `import React, { useState } from 'react';
export default function Governance({ pendingLeads, onValidate }: any) {
  const [sel, setSel] = useState('');
  return (
    <div className="max-w-2xl mx-auto space-y-12 animate-in zoom-in duration-500">
      <div className="bg-[#161b26] p-16 rounded-[4rem] border border-white/5 shadow-[0_50px_100px_rgba(0,0,0,0.5)] space-y-10 text-center">
        <div className="bg-primary/10 size-20 rounded-full mx-auto flex items-center justify-center text-primary"><span className="material-symbols-outlined text-4xl">verified_user</span></div>
        <h3 className="text-4xl font-black tracking-tighter italic uppercase">Gobernanza AI</h3>
        <select className="w-full bg-[#0a0f18] p-5 rounded-2xl border border-white/5 text-white font-black text-sm outline-none" value={sel} onChange={e => setSel(e.target.value)}>
          <option value="">Seleccionar Objetivo...</option>
          {pendingLeads.map((l: any) => <option key={l.id} value={l.id}>{l.title}</option>)}
        </select>
        <button onClick={() => {onValidate(sel, 'VALIDADO', 'ROI OK'); setSel('');}} className="w-full bg-primary py-6 rounded-[2rem] font-black text-xs uppercase shadow-2xl shadow-primary/40 active:scale-95 transition-all">Validar con Zeus Engine</button>
      </div>
    </div>
  );
}`,

  'pages/Offers.tsx': `import React from 'react';
export default function Offers({ offers, onAddOffer }: any) {
  return (
    <div className="space-y-10">
      <div className="flex justify-between items-end">
        <h2 className="text-5xl font-black tracking-tighter italic uppercase">Ofertas y Cierre</h2>
        <button onClick={() => onAddOffer({id: 'OF'+Date.now(), client: 'Nuevo Cliente', amount: '$120k', status: 'Enviada', type: 'B2B'})} className="bg-primary px-10 py-4 rounded-[2rem] font-black text-xs uppercase">Crear Nueva</button>
      </div>
      <div className="bg-[#161b26] rounded-[3rem] border border-white/5 overflow-hidden shadow-2xl">
        <table className="w-full text-left">
          <thead className="bg-white/5 text-[10px] font-black text-slate-500 uppercase tracking-widest italic"><tr><th className="p-8">Cliente</th><th className="p-8">Monto</th><th className="p-8">Estatus</th></tr></thead>
          <tbody className="divide-y divide-white/5">
            {offers.map((o: any) => <tr key={o.id} className="hover:bg-white/[0.02] transition-colors"><td className="p-8 font-black italic uppercase">{o.client}</td><td className="p-8 tabular-nums font-black text-primary">{o.amount}</td><td className="p-8"><span className="bg-primary/20 text-primary px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">{o.status}</span></td></tr>)}
          </tbody>
        </table>
      </div>
    </div>
  );
}`,

  'pages/Academy.tsx': `import React from 'react';
export default function Academy() {
  return (
    <div className="space-y-12">
      <h2 className="text-5xl font-black tracking-tighter italic uppercase text-center">Academia Zeus</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        <div className="bg-[#161b26] p-12 rounded-[3.5rem] border border-white/5 shadow-2xl group hover:border-primary/40 transition-all text-center">
          <h3 className="text-3xl font-black mb-4 italic uppercase">Expertise B2B</h3>
          <p className="text-slate-500 mb-8 leading-relaxed">Modelos avanzados de fidelización en flotas pesadas.</p>
          <button className="bg-primary/10 text-primary w-full py-5 rounded-3xl font-black text-[10px] uppercase group-hover:bg-primary group-hover:text-white transition-all">Iniciar Sesión</button>
        </div>
        <div className="bg-[#161b26] p-12 rounded-[3.5rem] border border-white/5 shadow-2xl group hover:border-primary/40 transition-all text-center">
          <h3 className="text-3xl font-black mb-4 italic uppercase">Expansión EDS</h3>
          <p className="text-slate-500 mb-8 leading-relaxed">Análisis de CAPEX y viabilidad de terrenos críticos.</p>
          <button className="bg-primary/10 text-primary w-full py-5 rounded-3xl font-black text-[10px] uppercase group-hover:bg-primary group-hover:text-white transition-all">Iniciar Sesión</button>
        </div>
      </div>
    </div>
  );
}`,

  'pages/KPIs.tsx': `import React from 'react';
export default function KPIs() { return <div className="p-20 text-center"><h2 className="text-5xl font-black italic uppercase">Métricas Avanzadas</h2><p className="mt-4 opacity-50 font-black uppercase tracking-widest">Sincronizando con Zeus Data Lake...</p></div> }`,

  'pages/Resources.tsx': `import React from 'react';
export default function Resources() { return <div className="max-w-4xl mx-auto space-y-10"><h2 className="text-6xl font-black italic uppercase text-center">Manual Maestro</h2><div className="p-12 bg-[#161b26] rounded-[3rem] border border-white/5 shadow-2xl leading-relaxed text-slate-400">Protocolo de comando para la gestión de activos territoriales y expansión de red. Versión 4.0 Pilot.</div></div> }`,

  'package.json': `{
    "name": "zeus-cce",
    "private": true,
    "version": "4.0.0",
    "type": "module",
    "scripts": { "dev": "vite", "build": "tsc && vite build", "preview": "vite preview" },
    "dependencies": { "react": "^19.0.0", "react-dom": "^19.0.0", "react-router-dom": "^7.0.0", "@google/genai": "^1.30.0", "lucide-react": "^0.450.0" },
    "devDependencies": { "vite": "^6.0.0", "typescript": "^5.0.0", "@types/react": "^19.0.0", "@types/react-dom": "^19.0.0" }
  }`
};

Object.entries(files).forEach(([name, content]) => {
  const dir = path.dirname(name);
  if (dir !== '.') fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(name, content);
  console.log('✅ ' + name);
});
console.log('\n🚀 DESPLIEGUE COMPLETO. Ejecuta: npm install && npm run dev');
